import os
import re
import csv
import io
import shutil
import sqlite3
import werkzeug.utils
from datetime import datetime, date, timedelta
from flask import (
    Flask, render_template, request, redirect, url_for, flash, jsonify, make_response, send_from_directory
)

# Optional image & OCR imports with graceful fallbacks
try:
    from PIL import Image
except Exception:
    Image = None

try:
    import pytesseract
except Exception:
    pytesseract = None

# Fast check for tesseract binary to avoid hanging on Windows process searches
TESSERACT_AVAILABLE = False
if pytesseract:
    try:
        standard_paths = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
        ]
        for p in standard_paths:
            if os.path.exists(p):
                pytesseract.pytesseract.tesseract_cmd = p
                TESSERACT_AVAILABLE = True
                break
        if not TESSERACT_AVAILABLE and shutil.which("tesseract"):
            TESSERACT_AVAILABLE = True
    except Exception:
        TESSERACT_AVAILABLE = False

try:
    from pyzbar import pyzbar
except Exception:
    pyzbar = None


app = Flask(__name__)
app.secret_key = "medicine_expiry_risk_system_secret_key_2026"

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'}

if os.environ.get("VERCEL"):
    DB_PATH = "/tmp/database.db"
    UPLOAD_FOLDER = "/tmp/uploads/scans"
else:
    DB_PATH = os.path.join(app.root_path, "database.db")
    UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads", "scans")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

RISK_THRESHOLDS = {
    'CRITICAL': 80,
    'HIGH': 60,
    'MEDIUM': 40,
    'LOW': 20,
    'SAFE': 0
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def ensure_db():
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    if not os.path.exists(DB_PATH):
        source_db = os.path.join(app.root_path, "database.db")
        if os.path.exists(source_db) and os.path.abspath(source_db) != os.path.abspath(DB_PATH):
            try:
                shutil.copy2(source_db, DB_PATH)
            except Exception:
                init_db()
        else:
            init_db()
    else:
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='medicines'")
            has_table = c.fetchone()
            conn.close()
            if not has_table:
                init_db()
        except Exception:
            init_db()

@app.before_request
def check_db_on_request():
    ensure_db()

def get_db():
    ensure_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Create medicines table with barcode column
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_name TEXT NOT NULL,
            batch_number TEXT NOT NULL,
            category TEXT NOT NULL,
            manufacturer TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            mfg_date DATE NOT NULL,
            expiry_date DATE NOT NULL,
            supplier TEXT NOT NULL,
            storage_location TEXT NOT NULL,
            min_stock_level INTEGER DEFAULT 10,
            monthly_usage INTEGER DEFAULT 10,
            barcode TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Check if barcode column exists in existing sqlite table
    cursor.execute("PRAGMA table_info(medicines)")
    columns = [row['name'] for row in cursor.fetchall()]
    if 'barcode' not in columns:
        cursor.execute("ALTER TABLE medicines ADD COLUMN barcode TEXT")

    # Create scan_history table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            image_path TEXT,
            extracted_name TEXT,
            extracted_batch TEXT,
            extracted_expiry TEXT,
            extracted_mfg TEXT,
            extracted_mrp REAL,
            barcode TEXT,
            ocr_status TEXT NOT NULL,          -- 'SUCCESS', 'PARTIAL', 'FAILED'
            confirmation_status TEXT NOT NULL,  -- 'PENDING', 'CONFIRMED', 'DISCARDED'
            medicine_id INTEGER
        )
    ''')
    
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_expiry ON medicines(expiry_date)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_name ON medicines(medicine_name)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_category ON medicines(category)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_barcode ON medicines(barcode)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_scan_date ON scan_history(scan_date)')
    
    conn.commit()

    cursor.execute('SELECT COUNT(*) as count FROM medicines')
    if cursor.fetchone()['count'] == 0:
        seed_database(conn)

    conn.close()

def seed_database(conn):
    today = date.today()
    sample_medicines = [
        ("Amoxicillin 500mg Capsule", "AMX-2023-88", "Antibiotics", "GlaxoSmithKline", 450, 14.50, 
         (today - timedelta(days=385)).strftime('%Y-%m-%d'), (today - timedelta(days=12)).strftime('%Y-%m-%d'),
         "PharmaDistributors Inc", "Rack A-12", 50, 60, "8901234567890"),

        ("Amphotericin B 50mg Injection", "AMP-9901", "Antibiotics", "Bharat Serums", 80, 85.00,
         (today - timedelta(days=360)).strftime('%Y-%m-%d'), (today - timedelta(days=5)).strftime('%Y-%m-%d'),
         "BioMed Supply", "Cold Refrigerator 1", 20, 15, "8909876543210"),

        ("Insulin Glargine 100IU/ml Pen", "INS-8842", "Diabetes Care", "Sanofi Aventis", 220, 45.00,
         (today - timedelta(days=170)).strftime('%Y-%m-%d'), (today + timedelta(days=8)).strftime('%Y-%m-%d'),
         "Novo Health Logistics", "Cold Refrigerator 2", 30, 40, "8901122334455"),

        ("Paracetamol 500mg Tablets", "PCM-9912", "Analgesics", "Cipla Ltd", 950, 2.50,
         (today - timedelta(days=350)).strftime('%Y-%m-%d'), (today + timedelta(days=18)).strftime('%Y-%m-%d'),
         "Universal Meds", "Shelf B-04", 100, 120, "8905566778899"),

        ("Cefuroxime Axetil 500mg", "CEF-4410", "Antibiotics", "Lupin Pharmaceuticals", 310, 22.00,
         (today - timedelta(days=300)).strftime('%Y-%m-%d'), (today + timedelta(days=25)).strftime('%Y-%m-%d'),
         "Apex Pharma", "Shelf A-08", 40, 50, "8906677889900"),

        ("Cetirizine 10mg Tablets", "CET-3321", "Respiratory", "Dr. Reddy's Labs", 600, 3.20,
         (today - timedelta(days=300)).strftime('%Y-%m-%d'), (today + timedelta(days=42)).strftime('%Y-%m-%d'),
         "Universal Meds", "Shelf C-01", 50, 80, "8907788990011"),

        ("Azithromycin 250mg Tablets", "AZI-7711", "Antibiotics", "Zydus Cadila", 420, 18.00,
         (today - timedelta(days=280)).strftime('%Y-%m-%d'), (today + timedelta(days=52)).strftime('%Y-%m-%d'),
         "Apex Pharma", "Shelf A-02", 30, 45, "8908899001122"),

        ("Metformin 500mg SR", "MET-5541", "Diabetes Care", "Sun Pharma", 800, 4.00,
         (today - timedelta(days=270)).strftime('%Y-%m-%d'), (today + timedelta(days=78)).strftime('%Y-%m-%d'),
         "PharmaDistributors Inc", "Shelf B-10", 100, 150, "8909900112233"),

        ("Omeprazole 20mg Capsules", "OME-1092", "Gastrointestinal", "Alkem Labs", 350, 5.50,
         (today - timedelta(days=200)).strftime('%Y-%m-%d'), (today + timedelta(days=88)).strftime('%Y-%m-%d'),
         "MedSupply Wholesale", "Shelf D-03", 40, 60, "8901011223344"),

        ("Atorvastatin 10mg Tablets", "ATO-6632", "Cardiovascular", "Pfizer Ltd", 500, 12.00,
         (today - timedelta(days=180)).strftime('%Y-%m-%d'), (today + timedelta(days=140)).strftime('%Y-%m-%d'),
         "Global Health Wholesalers", "Shelf C-09", 60, 90, "8902122334455"),

        ("Salbutamol Inhaler 100mcg", "SAL-2022", "Respiratory", "Cipla Ltd", 150, 15.00,
         (today - timedelta(days=150)).strftime('%Y-%m-%d'), (today + timedelta(days=165)).strftime('%Y-%m-%d'),
         "Universal Meds", "Cabinet 3", 20, 30, "8903233445566"),

        ("Vitamin C 500mg Chewable", "VIT-1002", "Vitamins & Supplements", "Abbott Healthcare", 1200, 1.80,
         (today - timedelta(days=90)).strftime('%Y-%m-%d'), (today + timedelta(days=340)).strftime('%Y-%m-%d'),
         "NutriHealth Direct", "Shelf E-01", 100, 200, "8904344556677"),

        ("Ibuprofen 400mg Tablets", "IBU-8821", "Analgesics", "McNeil Consumer", 300, 3.50,
         (today - timedelta(days=60)).strftime('%Y-%m-%d'), (today + timedelta(days=420)).strftime('%Y-%m-%d'),
         "MedSupply Wholesale", "Shelf B-02", 50, 70, "8905455667788"),

        ("Pantoprazole 40mg", "PAN-3049", "Gastrointestinal", "Torrent Pharma", 250, 6.00,
         (today - timedelta(days=40)).strftime('%Y-%m-%d'), (today + timedelta(days=280)).strftime('%Y-%m-%d'),
         "Apex Pharma", "Shelf D-05", 30, 40, "8906566778899")
    ]

    cursor = conn.cursor()
    for med in sample_medicines:
        cursor.execute('''
            INSERT INTO medicines 
            (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', med)
    conn.commit()

# ==============================================================================
# OCR & BARCODE EXTRACTION REGEX ENGINE
# ==============================================================================
def parse_date_to_iso(date_str):
    """Converts various label date formats (04/2027, 04-2027, 30/04/2027, EXP 04/27) to YYYY-MM-DD."""
    if not date_str:
        return ""
    date_str = date_str.strip().upper()
    
    # Clean noise prefixes
    date_str = re.sub(r'^(EXP|EXPR|EXPIRY|MFG|MFD|DATE)[:\.\s]*', '', date_str)
    
    month_names = {'JAN': '01', 'FEB': '02', 'MAR': '03', 'APR': '04', 'MAY': '05', 'JUN': '06',
                   'JUL': '07', 'AUG': '08', 'SEP': '09', 'OCT': '10', 'NOV': '11', 'DEC': '12'}
    
    for mname, mnum in month_names.items():
        if mname in date_str:
            date_str = date_str.replace(mname, mnum)
            
    # Try DD/MM/YYYY or DD-MM-YYYY
    match_dmy = re.search(r'(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})', date_str)
    if match_dmy:
        d, m, y = match_dmy.groups()
        if len(y) == 2:
            y = "20" + y
        return f"{int(y):04d}-{int(m):02d}-{int(d):02d}"

    # Try MM/YYYY or MM-YYYY
    match_my = re.search(r'(\d{1,2})[\/\-\.](\d{2,4})', date_str)
    if match_my:
        m, y = match_my.groups()
        if len(y) == 2:
            y = "20" + y
        # Default to first day of month or last day
        return f"{int(y):04d}-{int(m):02d}-01"

    return ""

def extract_medicine_info_from_text(raw_text):
    """
    Pattern-based extraction for medicine packaging labels:
    Medicine Name, Batch Number, Manufacturing Date, Expiry Date, MRP, Manufacturer, Strength.
    """
    info = {
        'medicine_name': '',
        'batch_number': '',
        'mfg_date': '',
        'expiry_date': '',
        'unit_price': 0.0,
        'manufacturer': '',
        'category': 'Other'
    }
    
    if not raw_text:
        return info

    lines = [line.strip() for line in raw_text.split('\n') if line.strip()]
    full_text = " ".join(lines).upper()

    # 1. EXPIRY DATE DETECTION
    expiry_match = re.search(r'(?:EXP|EXPIRY|EXP\.?\s*DATE|BEST BEFORE)[:\s\.\-]*([A-Z0-9\/\-\.]+)', full_text)
    if expiry_match:
        info['expiry_date'] = parse_date_to_iso(expiry_match.group(1))

    # 2. MANUFACTURING DATE DETECTION
    mfg_match = re.search(r'(?:MFG|MFD|MANUFACTURED|MFG\.?\s*DATE)[:\s\.\-]*([A-Z0-9\/\-\.]+)', full_text)
    if mfg_match:
        info['mfg_date'] = parse_date_to_iso(mfg_match.group(1))

    # 3. BATCH NUMBER DETECTION
    batch_match = re.search(r'(?:BATCH|B\.?NO|LOT)[:\s\.\-]*([A-Z0-9\-]+)', full_text)
    if batch_match:
        info['batch_number'] = batch_match.group(1)

    # 4. MRP / PRICE DETECTION
    mrp_match = re.search(r'(?:MRP|PRICE|RS|₹)[:\s\.\-]*[₹RS\.]*\s*(\d+(?:\.\d{1,2})?)', full_text)
    if mrp_match:
        try:
            info['unit_price'] = float(mrp_match.group(1))
        except ValueError:
            pass

    # 5. MEDICINE NAME & STRENGTH / CATEGORY DETECTION
    for line in lines:
        upper_line = line.upper()
        # Look for dosage forms or chemical names
        if any(term in upper_line for term in ['MG', 'ML', 'TABLET', 'CAPSULE', 'INJECTION', 'SYRUP', 'PAIN', '500', '250']):
            # Filter out lines that are clearly batch/exp lines
            if not any(k in upper_line for k in ['EXP', 'MFG', 'BATCH', 'MRP', 'B.NO']):
                info['medicine_name'] = line.title()
                break

    if not info['medicine_name'] and len(lines) > 0:
        info['medicine_name'] = lines[0].title()

    # Infer Category from keywords
    text_upper = full_text
    if 'AMOXICILLIN' in text_upper or 'CEFUROXIME' in text_upper or 'AZITHROMYCIN' in text_upper or 'ANTIBIOTIC' in text_upper:
        info['category'] = 'Antibiotics'
    elif 'PARACETAMOL' in text_upper or 'IBUPROFEN' in text_upper or 'PAIN' in text_upper:
        info['category'] = 'Analgesics'
    elif 'INSULIN' in text_upper or 'METFORMIN' in text_upper or 'DIABETES' in text_upper:
        info['category'] = 'Diabetes Care'
    elif 'CETIRIZINE' in text_upper or 'SALBUTAMOL' in text_upper or 'INHALER' in text_upper:
        info['category'] = 'Respiratory'
    elif 'OMEPRAZOLE' in text_upper or 'PANTOPRAZOLE' in text_upper:
        info['category'] = 'Gastrointestinal'
    elif 'VITAMIN' in text_upper or 'SUPPLEMENT' in text_upper:
        info['category'] = 'Vitamins & Supplements'

    return info

def perform_ocr_and_barcode(image_path):
    """Performs Tesseract OCR & PyZbar Barcode decoding on image path safely."""
    raw_text = ""
    barcode_val = ""
    ocr_status = 'FAILED'

    # Barcode Extraction
    if pyzbar and Image:
        try:
            img = Image.open(image_path)
            if max(img.size) > 1200:
                img.thumbnail((1200, 1200))
            decoded = pyzbar.decode(img)
            if decoded:
                barcode_val = decoded[0].data.decode('utf-8')
        except Exception:
            pass

    # OCR Extraction (Only called if tesseract binary is verified present, avoiding 20s Windows timeouts)
    if pytesseract and TESSERACT_AVAILABLE and Image:
        try:
            img = Image.open(image_path)
            if max(img.size) > 1200:
                img.thumbnail((1200, 1200))
            raw_text = pytesseract.image_to_string(img)
            if raw_text.strip():
                ocr_status = 'SUCCESS'
        except Exception:
            raw_text = ""
            ocr_status = 'PARTIAL'

    extracted_info = extract_medicine_info_from_text(raw_text)

    # Barcode fallback regex in text if pyzbar missed it
    if not barcode_val:
        bc_match = re.search(r'\b\d{12,13}\b', raw_text)
        if bc_match:
            barcode_val = bc_match.group(0)

    if extracted_info['expiry_date'] or extracted_info['batch_number'] or extracted_info['medicine_name']:
        ocr_status = 'SUCCESS' if ocr_status != 'FAILED' else 'PARTIAL'

    return raw_text, barcode_val, ocr_status, extracted_info


# ==============================================================================
# PRIORITY RISK ENGINE (CORE ALGORITHM)
# ==============================================================================
def calculate_risk_score(medicine):
    today = date.today()
    expiry_date_str = medicine['expiry_date']
    try:
        expiry_date = datetime.strptime(expiry_date_str, '%Y-%m-%d').date()
    except Exception:
        expiry_date = today

    days_remaining = (expiry_date - today).days
    quantity = int(medicine['quantity'])
    unit_price = float(medicine['unit_price'])
    monthly_usage = int(medicine['monthly_usage']) if medicine.get('monthly_usage') and int(medicine['monthly_usage']) > 0 else 1
    stock_value = quantity * unit_price

    # Expiry Proximity Score
    if days_remaining <= 0:
        expiry_pts = 100
    elif days_remaining <= 30:
        expiry_pts = 90
    elif days_remaining <= 60:
        expiry_pts = 75
    elif days_remaining <= 90:
        expiry_pts = 55
    elif days_remaining <= 180:
        expiry_pts = 35
    else:
        expiry_pts = 10

    # Stock Quantity Score
    if quantity >= 500:
        stock_pts = 100
    elif quantity >= 250:
        stock_pts = 75
    elif quantity >= 100:
        stock_pts = 50
    elif quantity >= 50:
        stock_pts = 30
    else:
        stock_pts = 15

    # Value Score
    if stock_value >= 5000:
        value_pts = 100
    elif stock_value >= 2000:
        value_pts = 80
    elif stock_value >= 1000:
        value_pts = 60
    elif stock_value >= 500:
        value_pts = 40
    elif stock_value >= 100:
        value_pts = 20
    else:
        value_pts = 10

    # Surplus Score
    months_of_supply = quantity / monthly_usage
    months_to_expiry = max(0.1, days_remaining / 30.0)

    if days_remaining <= 0:
        demand_pts = 100
    elif months_of_supply >= months_to_expiry:
        demand_pts = 100
    else:
        ratio = months_of_supply / months_to_expiry
        demand_pts = min(100.0, round(ratio * 75.0, 1))

    raw_score = (expiry_pts * 0.50) + (stock_pts * 0.20) + (value_pts * 0.15) + (demand_pts * 0.15)
    final_score = min(100, max(0, int(round(raw_score))))

    if final_score >= RISK_THRESHOLDS['CRITICAL']:
        priority = 'CRITICAL'
    elif final_score >= RISK_THRESHOLDS['HIGH']:
        priority = 'HIGH'
    elif final_score >= RISK_THRESHOLDS['MEDIUM']:
        priority = 'MEDIUM'
    elif final_score >= RISK_THRESHOLDS['LOW']:
        priority = 'LOW'
    else:
        priority = 'SAFE'

    if days_remaining <= 0:
        recommended_action = "QUARANTINE / REMOVE FROM USABLE STOCK"
    elif priority == 'CRITICAL':
        recommended_action = "Use immediately | Transfer to high-demand branch | Return to supplier"
    elif priority == 'HIGH':
        recommended_action = "Prioritize dispensing | Promote FEFO usage | Consider stock transfer"
    elif priority == 'MEDIUM':
        recommended_action = "Monitor inventory velocity | Prioritize normal usage"
    elif priority == 'LOW':
        recommended_action = "Regular inventory monitoring"
    else:
        recommended_action = "No immediate action required"

    explanations = []
    if days_remaining <= 0:
        explanations.append(f"❌ Expired {abs(days_remaining)} days ago ({medicine['expiry_date']}) → Maximum Expiry Risk")
    elif days_remaining <= 30:
        explanations.append(f"⚠️ Critical proximity: Only {days_remaining} days remaining until expiration")
    elif days_remaining <= 60:
        explanations.append(f"⚡ High proximity: {days_remaining} days remaining until expiration")
    elif days_remaining <= 90:
        explanations.append(f"📅 Moderate proximity: {days_remaining} days left until expiration")
    else:
        explanations.append(f"✓ Healthy proximity: {days_remaining} days left until expiration")

    if quantity >= 250:
        explanations.append(f"📦 High volume exposure: {quantity} units stored in batch")
    else:
        explanations.append(f"📦 Moderate/low quantity: {quantity} units stored")

    if stock_value >= 1000:
        explanations.append(f"💰 Financial exposure: ₹{stock_value:,.2f} tied up in batch stock")

    if months_of_supply > months_to_expiry and days_remaining > 0:
        explanations.append(f"📉 Surplus imbalance: {months_of_supply:.1f} months supply vs {months_to_expiry:.1f} months to expiry")

    return {
        'days_remaining': days_remaining,
        'stock_value': stock_value,
        'expiry_pts': expiry_pts,
        'stock_pts': stock_pts,
        'value_pts': value_pts,
        'demand_pts': demand_pts,
        'supply_months': months_of_supply,
        'risk_score': final_score,
        'priority': priority,
        'recommended_action': recommended_action,
        'explanations': explanations
    }

def process_medicine_record(row):
    med = dict(row)
    risk_info = calculate_risk_score(med)
    med.update(risk_info)
    return med


# ==============================================================================
# ROUTE HANDLERS
# ==============================================================================

@app.context_processor
def inject_global_data():
    today_str = date.today().strftime('%Y-%m-%d')
    return dict(today_date=today_str)

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()

    # Scanner statistics
    today_str = date.today().strftime('%Y-%m-%d')
    cursor.execute("SELECT COUNT(*) as count FROM scan_history WHERE DATE(scan_date) = ?", (today_str,))
    today_scans = cursor.fetchone()['count']

    cursor.execute("SELECT COUNT(*) as count FROM scan_history WHERE confirmation_status = 'CONFIRMED'")
    successful_scans = cursor.fetchone()['count']

    cursor.execute("SELECT COUNT(*) as count FROM scan_history WHERE confirmation_status = 'PENDING'")
    pending_scans = cursor.fetchone()['count']

    conn.close()

    medicines = [process_medicine_record(r) for r in rows]

    stats = {
        'total_medicines': len(medicines),
        'total_units': sum(m['quantity'] for m in medicines),
        'total_value': sum(m['stock_value'] for m in medicines),
        'expiring_30': sum(1 for m in medicines if 0 < m['days_remaining'] <= 30),
        'critical_count': sum(1 for m in medicines if m['priority'] == 'CRITICAL'),
        'expired_count': sum(1 for m in medicines if m['days_remaining'] <= 0)
    }

    scanner_stats = {
        'today_scans': today_scans,
        'successful_scans': successful_scans,
        'pending_scans': pending_scans
    }

    priority_counts = {
        'CRITICAL': sum(1 for m in medicines if m['priority'] == 'CRITICAL'),
        'HIGH': sum(1 for m in medicines if m['priority'] == 'HIGH'),
        'MEDIUM': sum(1 for m in medicines if m['priority'] == 'MEDIUM'),
        'LOW': sum(1 for m in medicines if m['priority'] == 'LOW'),
        'SAFE': sum(1 for m in medicines if m['priority'] == 'SAFE')
    }

    timeline_counts = {
        'expired': sum(1 for m in medicines if m['days_remaining'] <= 0),
        'd30': sum(1 for m in medicines if 0 < m['days_remaining'] <= 30),
        'd60': sum(1 for m in medicines if 30 < m['days_remaining'] <= 60),
        'd90': sum(1 for m in medicines if 60 < m['days_remaining'] <= 90),
        'd180': sum(1 for m in medicines if 90 < m['days_remaining'] <= 180),
        'dfar': sum(1 for m in medicines if m['days_remaining'] > 180)
    }

    chart_data = {
        'priority_counts': priority_counts,
        'timeline_counts': timeline_counts
    }

    top_10 = sorted(medicines, key=lambda x: x['risk_score'], reverse=True)[:10]

    alert_stats = {
        'expired': stats['expired_count'],
        'critical': stats['critical_count'],
        'd30': stats['expiring_30']
    }

    return render_template(
        'dashboard.html',
        active_page='dashboard',
        stats=stats,
        scanner_stats=scanner_stats,
        chart_data=chart_data,
        top_10_medicines=top_10,
        alert_stats=alert_stats,
        critical_count=stats['critical_count'],
        alert_count=stats['expired_count'] + stats['expiring_30']
    )

# ==============================================================================
# MEDICINE SCANNER ROUTES
# ==============================================================================
@app.route('/scanner')
def scanner():
    return render_template('scanner.html', active_page='scanner')

@app.route('/scanner/upload', methods=['POST'])
def scanner_upload():
    if 'medicine_image' not in request.files and 'image_data' not in request.form:
        return jsonify({'success': False, 'message': 'No image file or camera capture received.'}), 400

    filename = ""
    rel_path = ""
    filepath = ""

    # Case A: File upload
    if 'medicine_image' in request.files and request.files['medicine_image'].filename != '':
        file = request.files['medicine_image']
        if file and allowed_file(file.filename):
            sec_filename = werkzeug.utils.secure_filename(file.filename)
            timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"scan_{timestamp_str}_{sec_filename}"
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            rel_path = f"uploads/scans/{filename}"
        else:
            return jsonify({'success': False, 'message': 'Invalid file format. Allowed: PNG, JPG, JPEG, WEBP'}), 400

    # Case B: Camera Base64 Snapshot
    elif 'image_data' in request.form:
        import base64
        image_data = request.form['image_data']
        if ',' in image_data:
            image_data = image_data.split(',')[1]
        timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"camera_scan_{timestamp_str}.jpg"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        with open(filepath, "wb") as fh:
            fh.write(base64.b64decode(image_data))
        rel_path = f"uploads/scans/{filename}"

    # Check for client-supplied OCR text & barcode from Tesseract.js / ZXing JS
    client_ocr_text = request.form.get('client_ocr_text', '').strip()
    client_barcode = request.form.get('client_barcode', '').strip()

    # Perform Server-Side OCR and Barcode Analysis
    raw_text, barcode_val, ocr_status, extracted_info = perform_ocr_and_barcode(filepath)

    # Combine client and server text for maximum regex pattern matching accuracy
    combined_text = (client_ocr_text + "\n" + raw_text).strip()
    if combined_text:
        extracted_info = extract_medicine_info_from_text(combined_text)

    if client_barcode and not barcode_val:
        barcode_val = client_barcode

    if combined_text:
        ocr_status = 'SUCCESS'

    # Check for Duplicate Barcode or Batch in Medicines table
    existing_med = None
    conn = get_db()
    cursor = conn.cursor()

    
    if barcode_val:
        cursor.execute("SELECT id, medicine_name, batch_number FROM medicines WHERE barcode = ?", (barcode_val,))
        match = cursor.fetchone()
        if match:
            existing_med = dict(match)

    if not existing_med and extracted_info.get('batch_number'):
        cursor.execute("SELECT id, medicine_name, batch_number FROM medicines WHERE batch_number = ?", (extracted_info['batch_number'],))
        match = cursor.fetchone()
        if match:
            existing_med = dict(match)

    # Save to scan_history table (PENDING confirmation)
    cursor.execute('''
        INSERT INTO scan_history
        (image_path, extracted_name, extracted_batch, extracted_expiry, extracted_mfg, extracted_mrp, barcode, ocr_status, confirmation_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        rel_path,
        extracted_info.get('medicine_name', ''),
        extracted_info.get('batch_number', ''),
        extracted_info.get('expiry_date', ''),
        extracted_info.get('mfg_date', ''),
        extracted_info.get('unit_price', 0.0),
        barcode_val,
        ocr_status,
        'PENDING'
    ))
    conn.commit()
    scan_id = cursor.lastrowid
    conn.close()

    return jsonify({
        'success': True,
        'scan_id': scan_id,
        'image_url': url_for('uploaded_scan_file', filename=filename) if filename else '',
        'barcode': barcode_val,
        'ocr_status': ocr_status,
        'extracted': extracted_info,
        'existing_med': existing_med
    })

@app.route('/uploads/scans/<path:filename>')
@app.route('/static/uploads/scans/<path:filename>')
def uploaded_scan_file(filename):
    clean_filename = os.path.basename(filename)
    if os.path.exists(os.path.join(UPLOAD_FOLDER, clean_filename)):
        return send_from_directory(UPLOAD_FOLDER, clean_filename)
    static_scans = os.path.join(app.root_path, "static", "uploads", "scans")
    if os.path.exists(os.path.join(static_scans, clean_filename)):
        return send_from_directory(static_scans, clean_filename)
    return ('', 204)

@app.route('/medicine/by-barcode/<barcode>')
def medicine_by_barcode(barcode):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines WHERE barcode = ?', (barcode,))
    row = cursor.fetchone()
    conn.close()

    if row:
        med = process_medicine_record(row)
        return jsonify({'found': True, 'medicine': med})
    return jsonify({'found': False})

@app.route('/scanner/confirm', methods=['POST'])
def scanner_confirm():

    scan_id = request.form.get('scan_id')
    medicine_name = request.form.get('medicine_name', '').strip()
    batch_number = request.form.get('batch_number', '').strip()
    category = request.form.get('category', 'Other').strip()
    manufacturer = request.form.get('manufacturer', '').strip()
    
    try:
        quantity = int(request.form.get('quantity', 50) or 50)
    except (ValueError, TypeError):
        quantity = 50

    try:
        unit_price = float(request.form.get('unit_price', 0.0) or 0.0)
    except (ValueError, TypeError):
        unit_price = 0.0

    mfg_date = request.form.get('mfg_date', '').strip()
    expiry_date = request.form.get('expiry_date', '').strip()
    supplier = request.form.get('supplier', 'Scanner Input').strip()
    storage_location = request.form.get('storage_location', 'Rack A-1').strip()
    
    try:
        min_stock_level = int(request.form.get('min_stock_level', 10) or 10)
    except (ValueError, TypeError):
        min_stock_level = 10

    try:
        monthly_usage = int(request.form.get('monthly_usage', 10) or 10)
    except (ValueError, TypeError):
        monthly_usage = 10

    barcode = request.form.get('barcode', '').strip()

    if not medicine_name or not batch_number or not expiry_date:
        flash("Please provide Medicine Name, Batch Number, and Expiry Date.", "danger")
        return redirect(url_for('scanner'))

    conn = get_db()
    cursor = conn.cursor()
    
    # Save into medicines table
    cursor.execute('''
        INSERT INTO medicines 
        (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode))
    conn.commit()
    new_med_id = cursor.lastrowid

    # Update scan_history status to CONFIRMED
    if scan_id:
        cursor.execute('''
            UPDATE scan_history
            SET confirmation_status = 'CONFIRMED', medicine_id = ?
            WHERE id = ?
        ''', (new_med_id, scan_id))
        conn.commit()

    conn.close()

    # Calculate risk score feedback summary
    med_record = {
        'id': new_med_id,
        'medicine_name': medicine_name,
        'batch_number': batch_number,
        'category': category,
        'manufacturer': manufacturer,
        'quantity': quantity,
        'unit_price': unit_price,
        'mfg_date': mfg_date,
        'expiry_date': expiry_date,
        'supplier': supplier,
        'storage_location': storage_location,
        'min_stock_level': min_stock_level,
        'monthly_usage': monthly_usage,
        'barcode': barcode
    }
    risk = calculate_risk_score(med_record)

    flash(
        f"✓ Medicine '{medicine_name}' successfully added! | Risk Score: {risk['risk_score']}/100 | Priority: {risk['priority']} | Days Left: {risk['days_remaining']} | Recommended Action: {risk['recommended_action']}",
        "success"
    )
    return redirect(url_for('medicine_details', id=new_med_id))

@app.route('/scan-history')
def scan_history():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM scan_history ORDER BY scan_date DESC')
    rows = cursor.fetchall()
    conn.close()

    history = [dict(r) for r in rows]
    return render_template('scan_history.html', active_page='scan_history', history=history)

@app.route('/scan-history/<int:id>/delete', methods=['POST'])
def delete_scan_history(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM scan_history WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash("Scan history record removed.", "info")
    return redirect(url_for('scan_history'))


# ==============================================================================
# EXISTING INVENTORY ROUTES
# ==============================================================================

@app.route('/medicines')
def medicines():
    search = request.args.get('search', '').strip()
    priority = request.args.get('priority', '').strip()
    category = request.args.get('category', '').strip()
    expiry_range = request.args.get('expiry_range', '').strip()
    sort_by = request.args.get('sort', 'risk_desc').strip()

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()
    
    cursor.execute('SELECT DISTINCT category FROM medicines ORDER BY category ASC')
    categories = [r['category'] for r in cursor.fetchall()]
    conn.close()

    medicines_list = [process_medicine_record(r) for r in rows]

    if search:
        s_lower = search.lower()
        medicines_list = [m for m in medicines_list if 
                          s_lower in m['medicine_name'].lower() or
                          s_lower in m['batch_number'].lower() or
                          s_lower in m['category'].lower() or
                          s_lower in m['manufacturer'].lower() or
                          s_lower in (m['barcode'] or '').lower() or
                          s_lower in m['supplier'].lower()]

    if priority:
        medicines_list = [m for m in medicines_list if m['priority'] == priority]

    if category:
        medicines_list = [m for m in medicines_list if m['category'] == category]

    if expiry_range:
        if expiry_range == 'EXPIRED':
            medicines_list = [m for m in medicines_list if m['days_remaining'] <= 0]
        elif expiry_range == '30':
            medicines_list = [m for m in medicines_list if 0 < m['days_remaining'] <= 30]
        elif expiry_range == '60':
            medicines_list = [m for m in medicines_list if 0 < m['days_remaining'] <= 60]
        elif expiry_range == '90':
            medicines_list = [m for m in medicines_list if 0 < m['days_remaining'] <= 90]
        elif expiry_range == '180':
            medicines_list = [m for m in medicines_list if 0 < m['days_remaining'] <= 180]

    if sort_by == 'risk_desc':
        medicines_list.sort(key=lambda x: x['risk_score'], reverse=True)
    elif sort_by == 'risk_asc':
        medicines_list.sort(key=lambda x: x['risk_score'])
    elif sort_by == 'expiry_asc':
        medicines_list.sort(key=lambda x: x['days_remaining'])
    elif sort_by == 'expiry_desc':
        medicines_list.sort(key=lambda x: x['days_remaining'], reverse=True)
    elif sort_by == 'name_asc':
        medicines_list.sort(key=lambda x: x['medicine_name'].lower())

    filters = {
        'search': search,
        'priority': priority,
        'category': category,
        'expiry_range': expiry_range,
        'sort': sort_by
    }

    return render_template(
        'medicines.html',
        active_page='medicines',
        medicines=medicines_list,
        categories=categories,
        filters=filters
    )

@app.route('/medicine/add', methods=['GET', 'POST'])
def add_medicine():
    if request.method == 'POST':
        medicine_name = request.form.get('medicine_name', '').strip()
        batch_number = request.form.get('batch_number', '').strip()
        category = request.form.get('category', '').strip()
        manufacturer = request.form.get('manufacturer', '').strip()
        quantity = int(request.form.get('quantity', 0))
        unit_price = float(request.form.get('unit_price', 0.0))
        mfg_date = request.form.get('mfg_date', '').strip()
        expiry_date = request.form.get('expiry_date', '').strip()
        supplier = request.form.get('supplier', '').strip()
        storage_location = request.form.get('storage_location', '').strip()
        min_stock_level = int(request.form.get('min_stock_level', 10))
        monthly_usage = int(request.form.get('monthly_usage', 10))
        barcode = request.form.get('barcode', '').strip()

        if not medicine_name or not batch_number or not category or not expiry_date:
            flash("Please fill in all required fields.", "danger")
            return redirect(url_for('add_medicine'))

        if quantity < 0 or unit_price < 0:
            flash("Quantity and Unit Price cannot be negative.", "danger")
            return redirect(url_for('add_medicine'))

        if mfg_date and expiry_date and expiry_date <= mfg_date:
            flash("Expiry Date must be after Manufacturing Date.", "danger")
            return redirect(url_for('add_medicine'))

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO medicines 
            (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode))
        conn.commit()
        conn.close()

        flash(f"Medicine batch '{medicine_name}' ({batch_number}) registered successfully!", "success")
        return redirect(url_for('medicines'))

    return render_template('add_medicine.html', active_page='add_medicine')

@app.route('/medicine/<int:id>')
def medicine_details(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines WHERE id = ?', (id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        flash("Medicine record not found.", "danger")
        return redirect(url_for('medicines'))

    med = dict(row)
    risk_info = calculate_risk_score(med)

    return render_template('medicine_details.html', active_page='medicines', medicine=med, risk=risk_info)

@app.route('/medicine/<int:id>/edit', methods=['GET', 'POST'])
def edit_medicine(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines WHERE id = ?', (id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        flash("Medicine record not found.", "danger")
        return redirect(url_for('medicines'))

    if request.method == 'POST':
        medicine_name = request.form.get('medicine_name', '').strip()
        batch_number = request.form.get('batch_number', '').strip()
        category = request.form.get('category', '').strip()
        manufacturer = request.form.get('manufacturer', '').strip()
        quantity = int(request.form.get('quantity', 0))
        unit_price = float(request.form.get('unit_price', 0.0))
        mfg_date = request.form.get('mfg_date', '').strip()
        expiry_date = request.form.get('expiry_date', '').strip()
        supplier = request.form.get('supplier', '').strip()
        storage_location = request.form.get('storage_location', '').strip()
        min_stock_level = int(request.form.get('min_stock_level', 10))
        monthly_usage = int(request.form.get('monthly_usage', 10))
        barcode = request.form.get('barcode', '').strip()

        if quantity < 0 or unit_price < 0:
            flash("Quantity and Unit Price cannot be negative.", "danger")
            return redirect(url_for('edit_medicine', id=id))

        if mfg_date and expiry_date and expiry_date <= mfg_date:
            flash("Expiry Date must be after Manufacturing Date.", "danger")
            return redirect(url_for('edit_medicine', id=id))

        cursor.execute('''
            UPDATE medicines 
            SET medicine_name=?, batch_number=?, category=?, manufacturer=?, quantity=?, unit_price=?, 
                mfg_date=?, expiry_date=?, supplier=?, storage_location=?, min_stock_level=?, monthly_usage=?, barcode=?
            WHERE id=?
        ''', (medicine_name, batch_number, category, manufacturer, quantity, unit_price, mfg_date, expiry_date, supplier, storage_location, min_stock_level, monthly_usage, barcode, id))
        conn.commit()
        conn.close()

        flash(f"Medicine batch '{medicine_name}' updated and risk score recalculated!", "success")
        return redirect(url_for('medicine_details', id=id))

    med = dict(row)
    conn.close()
    return render_template('edit_medicine.html', active_page='medicines', medicine=med)

@app.route('/medicine/<int:id>/delete', methods=['POST'])
def delete_medicine(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT medicine_name, batch_number FROM medicines WHERE id = ?', (id,))
    row = cursor.fetchone()

    if row:
        cursor.execute('DELETE FROM medicines WHERE id = ?', (id,))
        conn.commit()
        flash(f"Medicine batch '{row['medicine_name']}' ({row['batch_number']}) deleted from inventory.", "info")
    else:
        flash("Record not found.", "danger")

    conn.close()
    return redirect(url_for('medicines'))

@app.route('/priority-queue')
def priority_queue():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()
    conn.close()

    medicines = [process_medicine_record(r) for r in rows]
    ranked = sorted(medicines, key=lambda x: (-x['risk_score'], x['days_remaining']))

    return render_template('priority_queue.html', active_page='priority_queue', ranked_medicines=ranked)

@app.route('/expiry-alerts')
def expiry_alerts():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()
    conn.close()

    medicines = [process_medicine_record(r) for r in rows]

    alerts = {
        'expired': sorted([m for m in medicines if m['days_remaining'] <= 0], key=lambda x: x['days_remaining']),
        'd7': sorted([m for m in medicines if 0 < m['days_remaining'] <= 7], key=lambda x: x['days_remaining']),
        'd30': sorted([m for m in medicines if 0 < m['days_remaining'] <= 30], key=lambda x: x['days_remaining']),
        'd60': sorted([m for m in medicines if 0 < m['days_remaining'] <= 60], key=lambda x: x['days_remaining']),
        'd90': sorted([m for m in medicines if 0 < m['days_remaining'] <= 90], key=lambda x: x['days_remaining']),
    }

    return render_template('expiry_alerts.html', active_page='expiry_alerts', alerts=alerts)

@app.route('/reports')
def reports():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()
    conn.close()

    medicines = [process_medicine_record(r) for r in rows]
    medicines_sorted = sorted(medicines, key=lambda x: x['risk_score'], reverse=True)

    total_value = sum(m['stock_value'] for m in medicines)
    expired_value = sum(m['stock_value'] for m in medicines if m['days_remaining'] <= 0)
    expired_units = sum(m['quantity'] for m in medicines if m['days_remaining'] <= 0)

    at_risk = [m for m in medicines if m['priority'] in ('CRITICAL', 'HIGH') and m['days_remaining'] > 0]
    at_risk_value = sum(m['stock_value'] for m in at_risk)
    at_risk_units = sum(m['quantity'] for m in at_risk)

    priority_summary = {
        'CRITICAL': {'count': 0, 'units': 0, 'value': 0.0},
        'HIGH': {'count': 0, 'units': 0, 'value': 0.0},
        'MEDIUM': {'count': 0, 'units': 0, 'value': 0.0},
        'LOW': {'count': 0, 'units': 0, 'value': 0.0},
        'SAFE': {'count': 0, 'units': 0, 'value': 0.0}
    }

    category_summary = {}

    for m in medicines:
        p = m['priority']
        priority_summary[p]['count'] += 1
        priority_summary[p]['units'] += m['quantity']
        priority_summary[p]['value'] += m['stock_value']

        cat = m['category']
        if cat not in category_summary:
            category_summary[cat] = {'count': 0, 'units': 0, 'value': 0.0, 'critical_count': 0}
        category_summary[cat]['count'] += 1
        category_summary[cat]['units'] += m['quantity']
        category_summary[cat]['value'] += m['stock_value']
        if p in ('CRITICAL', 'HIGH'):
            category_summary[cat]['critical_count'] += 1

    report_data = {
        'total_medicines': len(medicines),
        'total_value': total_value,
        'expired_value': expired_value,
        'expired_units': expired_units,
        'at_risk_value': at_risk_value,
        'at_risk_units': at_risk_units,
        'priority_summary': priority_summary,
        'category_summary': category_summary,
        'all_medicines': medicines_sorted
    }

    return render_template('reports.html', active_page='reports', report=report_data)

@app.route('/export-csv')
def export_csv():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM medicines')
    rows = cursor.fetchall()
    conn.close()

    medicines = [process_medicine_record(r) for r in rows]
    medicines.sort(key=lambda x: x['risk_score'], reverse=True)

    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'ID', 'Medicine Name', 'Batch Number', 'Barcode', 'Category', 'Manufacturer', 
        'Quantity', 'Unit Price (₹)', 'Stock Value (₹)', 'MFG Date', 'Expiry Date', 
        'Days Remaining', 'Supplier', 'Storage Location', 'Risk Score (0-100)', 
        'Priority Level', 'Recommended Action'
    ])

    for m in medicines:
        writer.writerow([
            m['id'], m['medicine_name'], m['batch_number'], m.get('barcode', ''), m['category'], m['manufacturer'],
            m['quantity'], f"{m['unit_price']:.2f}", f"{m['stock_value']:.2f}", m['mfg_date'], m['expiry_date'],
            m['days_remaining'], m['supplier'], m['storage_location'], m['risk_score'],
            m['priority'], m['recommended_action']
        ])

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=medicine_expiry_risk_report.csv"
    response.headers["Content-type"] = "text/csv"
    return response

@app.route('/download-scanner-guide')
@app.route('/scanner-guide-pdf')
def download_scanner_guide():
    pdf_filename = 'MEDICINE_SCANNER_GUIDE.pdf'
    pdf_path = os.path.join(app.root_path, pdf_filename)
    if os.path.exists(pdf_path):
        return send_from_directory(app.root_path, pdf_filename, as_attachment=True)
    return "Scanner guide PDF not found.", 404

if __name__ == '__main__':
    init_db()
    print("=" * 70)
    print(" Priority-Based Medicine Expiry Risk Identification System")
    print(" Running on http://127.0.0.1:5000")
    print("=" * 70)
    app.run(debug=False, host='0.0.0.0', port=5000)
