/* Priority-Based Medicine Expiry Risk Identification System JavaScript */

document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar on mobile/desktop toggle button if exists
    const menuToggle = document.getElementById('menu-toggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('wrapper').classList.toggle('toggled');
        });
    }

    const closeSidebar = document.getElementById('closeSidebar');
    if (closeSidebar) {
        closeSidebar.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('wrapper').classList.remove('toggled');
        });
    }


    // Initialize Dashboard Charts if elements exist
    initRiskOverviewChart();
    initExpiryTimelineChart();
});

// Render Doughnut Chart for Priority Breakdown
function initRiskOverviewChart() {
    const canvas = document.getElementById('riskOverviewChart');
    if (!canvas) return;

    const criticalCount = parseInt(canvas.dataset.critical || 0);
    const highCount = parseInt(canvas.dataset.high || 0);
    const mediumCount = parseInt(canvas.dataset.medium || 0);
    const lowCount = parseInt(canvas.dataset.low || 0);
    const safeCount = parseInt(canvas.dataset.safe || 0);

    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Critical (80-100)', 'High (60-79)', 'Medium (40-59)', 'Low (20-39)', 'Safe (0-19)'],
            datasets: [{
                data: [criticalCount, highCount, mediumCount, lowCount, safeCount],
                backgroundColor: [
                    '#dc3545', // Critical
                    '#fd7e14', // High
                    '#ffc107', // Medium
                    '#0dcaf0', // Low
                    '#198754'  // Safe
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        font: { size: 12, weight: '500' }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return ` ${label}: ${value} items (${percentage}%)`;
                        }
                    }
                }
            },
            cutout: '65%'
        }
    });
}

// Render Bar Chart for Medicines Expiring Over Time
function initExpiryTimelineChart() {
    const canvas = document.getElementById('expiryTimelineChart');
    if (!canvas) return;

    const expired = parseInt(canvas.dataset.expired || 0);
    const d30 = parseInt(canvas.dataset.d30 || 0);
    const d60 = parseInt(canvas.dataset.d60 || 0);
    const d90 = parseInt(canvas.dataset.d90 || 0);
    const d180 = parseInt(canvas.dataset.d180 || 0);
    const dFar = parseInt(canvas.dataset.dfar || 0);

    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Expired', '0-30 Days', '31-60 Days', '61-90 Days', '91-180 Days', '> 180 Days'],
            datasets: [{
                label: 'Number of Medicines',
                data: [expired, d30, d60, d90, d180, dFar],
                backgroundColor: [
                    '#b02a37',
                    '#dc3545',
                    '#fd7e14',
                    '#ffc107',
                    '#0dcaf0',
                    '#198754'
                ],
                borderRadius: 6,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return ` ${context.raw} Medicines`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 },
                    grid: { color: '#f1f5f9' }
                }
            }
        }
    });
}
