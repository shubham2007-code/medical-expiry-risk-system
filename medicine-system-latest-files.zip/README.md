# Priority-Based Medicine Expiry Risk Identification System

A full-stack, intelligent web platform and decision-support system designed for pharmacies, hospital inventory managers, and medical stores to dynamically identify, calculate, and prioritize pharmaceutical stock at risk of expiration.

> 📄 **Official Feature Guide & Specification PDF:** [`MEDICINE_SCANNER_GUIDE.pdf`](MEDICINE_SCANNER_GUIDE.pdf) contains the full technical specification, dual-engine pipeline architecture, and pharmacist SOP for the Smart Packaging Scanner & AI OCR system.

---

## 📌 Problem Statement
In pharmacies and healthcare inventory management:
1. **Financial Wastage**: Millions of dollars worth of medicines expire every year on pharmacy shelves due to lack of proactive prioritization.
2. **Clinical Hazards**: Accidentally dispensing expired or near-expiry drugs poses critical health risks to patients.
3. **Limitation of Traditional Trackers**: Standard inventory software simply sorts medicines by expiry date. However, expiry date alone does not reflect true inventory risk. A batch of 500 units expiring in 20 days with zero sales velocity represents a far higher financial and logistical risk than 2 units expiring in 10 days that will be dispensed today.

---

## 🎯 Objective
This platform addresses these challenges by introducing a **Transparent Multi-Factor Risk Calculation Engine**. Rather than relying on simple date sorting, it evaluates every medicine batch across 4 key dimensions—Expiry Proximity, Stock Volume, Financial Value, and Demand Surplus—producing a normalized **0–100 Expiry Risk Score** and an actionable **Priority Level** (CRITICAL, HIGH, MEDIUM, LOW, SAFE).

---

## ✨ Key Features
- **Smart Medicine Scanner & OCR (New!)**: Scan barcodes via webcam/smartphone camera or upload medicine packaging photos. Employs Tesseract.js & PyZbar regex parsing to extract Medicine Name, Batch Number, Manufacturing Date, and Expiry Date with instant risk preview.
- **Executive Dashboard**: Interactive metric cards, Chart.js visual graphs (Priority Breakdown & Expiry Timeline), and real-time alert banners.
- **Smart Priority Queue (FEFO Protocol)**: Ranks medicines dynamically from highest risk to lowest risk, guiding pharmacists on exact First-Expiry, First-Out dispensing sequences.
- **Transparent "Why This Score?" Audit**: Detailed visual breakdown for every medicine batch showing factor-by-factor score contributions and human-readable explanations.
- **Categorized Time-Horizon Alerts**: Separate alert tabs for Already Expired, $\le 7$ days, $\le 30$ days, $\le 60$ days, and $\le 90$ days.
- **Inventory CRUD Operations**: Search, filter by category/priority/expiry window, sort, add, edit, and delete items with full validation.
- **Loss Prevention Reports & CSV Export**: Detailed financial exposure summaries, category risk tables, print-ready reports, and one-click CSV export.

---

## 🛠️ Technology Stack
- **Backend**: Python (Flask 3.x Framework, Serverless WSGI)
- **Database**: SQLite3 (automatic table schema generation & persistent initialization)
- **OCR & Barcode Extraction**: HTML5-QRCode, Tesseract.js v5, Pillow, PyZbar
- **Frontend**: HTML5, CSS3, Bootstrap 5, Bootstrap Icons
- **Data Visualization**: Chart.js
- **Deployment**: Vercel Serverless (`@vercel/python` / `api/index.py`)

---

## 🧮 Priority-Based Risk Calculation Methodology

The system computes a weighted risk score ($0 - 100$) using the following transparent algorithm:

$$\text{Risk Score} = (S_{\text{expiry}} \times 0.50) + (S_{\text{stock}} \times 0.20) + (S_{\text{value}} \times 0.15) + (S_{\text{surplus}} \times 0.15)$$

### 1. Factor Scoring Matrix
- **Expiry Proximity ($S_{\text{expiry}}$ - 50% Weight)**:
  - Expired ($\le 0$ days remaining): $100$ pts
  - $1 - 30$ days: $90$ pts
  - $31 - 60$ days: $75$ pts
  - $61 - 90$ days: $55$ pts
  - $91 - 180$ days: $35$ pts
  - $> 180$ days: $10$ pts

- **Stock Quantity Exposure ($S_{\text{stock}}$ - 20% Weight)**:
  - $\ge 500$ units: $100$ pts
  - $\ge 250$ units: $75$ pts
  - $\ge 100$ units: $50$ pts
  - $\ge 50$ units: $30$ pts
  - $< 50$ units: $15$ pts

---

## 💻 How to Run Locally

### Prerequisites
- Python 3.8+ installed on your system.

### Steps to Run:
1. **Open your terminal / command prompt** and navigate to the project directory:
   ```bash
   cd medicine-expiry-risk-system
   ```

2. **Install required dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the Flask Server**:
   ```bash
   python app.py
   ```

4. **Access the application in your web browser**:
   Open `http://127.0.0.1:5000`

---

## 🚀 Deploying to Vercel

This repository is pre-configured with `vercel.json` and `api/index.py` for seamless 1-click deployment on Vercel:

1. **Push your code to GitHub**:
   ```bash
   git add .
   git commit -m "Add smart medicine scanner and Vercel configuration"
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git push -u origin main
   ```

2. **Deploy on Vercel**:
   - Go to [vercel.com](https://vercel.com) and log in.
   - Click **"Add New..."** -> **"Project"**.
   - Select your GitHub repository.
   - Click **Deploy**! Vercel will automatically build and deploy your application.

---

## 🎓 How to Explain This Project to an Evaluator

1. **Not Just a CRUD App**: This is a **Priority-Based Decision Support System (DSS)** with real-time computer vision / OCR packaging scanning.
2. **Multi-Factor Intelligence vs. Simple Sorting**:
   - *Traditional system*: "Sort by Expiry Date ASC" -> misses high-quantity or high-value items about to expire.
   - *Our system*: Evaluates **Expiry Proximity + Quantity Exposure + Financial Capital + Sales Velocity**.
3. **FEFO Integration**: Enforces First-Expiry, First-Out sequence to avoid medicine expiration on shelves.
4. **Transparent Risk Audit**: Shows exact score contributions and calculations for complete explainability.

- **Financial Value Exposure ($S_{\text{value}}$ - 15% Weight)** ($\text{Value} = \text{Qty} \times \text{Price}$):
  - $\ge ₹5,000$: $100$ pts
  - $\ge ₹2,000$: $80$ pts
  - $\ge ₹1,000$: $60$ pts
  - $\ge ₹500$: $40$ pts
  - $\ge ₹100$: $20$ pts
  - $< ₹100$: $10$ pts

- **Demand Surplus Exposure ($S_{\text{surplus}}$ - 15% Weight)**:
  - Calculates Supply Months ($\frac{\text{Current Stock}}{\text{Monthly Usage}}$) vs Expiry Months ($\frac{\text{Days Left}}{30}$).
  - If Supply Months $\ge$ Expiry Months: Assigns $100$ pts (Guaranteed expiration before complete usage).

### 2. Configurable Priority Thresholds
| Risk Score Range | Priority Level | Badge Color | Default Recommended Action |
| :--- | :--- | :--- | :--- |
| **80 – 100** | **CRITICAL** | Red | Use immediately \| Transfer to high-demand branch \| Return to supplier |
| **60 – 79** | **HIGH** | Orange | Prioritize dispensing \| Promote FEFO usage \| Consider stock transfer |
| **40 – 59** | **MEDIUM** | Yellow | Monitor inventory velocity \| Prioritize normal usage |
| **20 – 39** | **LOW** | Blue | Regular inventory monitoring |
| **0 – 19** | **SAFE** | Green | No immediate action required |

*Note: For expired medicines ($\text{Days Left} \le 0$), action defaults to `"QUARANTINE / REMOVE FROM USABLE STOCK"`.*

---

## 🗄️ Database Structure

File: `database.db` (SQLite)

```sql
CREATE TABLE medicines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    medicine_name TEXT NOT NULL,
    batch_number TEXT NOT NULL,
    category TEXT NOT NULL,
    manufacturer TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    mfg_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    supplier TEXT NOT NULL,
    storage_location TEXT NOT NULL,
    min_stock_level INTEGER DEFAULT 10,
    monthly_usage INTEGER DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_expiry ON medicines(expiry_date);
CREATE INDEX idx_name ON medicines(medicine_name);
CREATE INDEX idx_category ON medicines(category);
```

---

## 📁 Project Directory Structure

```
medicine-expiry-risk-system/
│
├── app.py                      # Flask routes, risk engine, DB initialization, seed data
├── database.db                 # SQLite database (auto-generated on app launch)
├── requirements.txt            # Python dependencies (Flask)
├── README.md                   # Project documentation and presentation guide
│
├── templates/
│   ├── base.html               # Master layout, responsive sidebar, flash notifications
│   ├── dashboard.html          # Metric cards, Chart.js graphs, Top 10 attention table
│   ├── medicines.html          # Inventory list, filter toolbar, search, pagination/sort
│   ├── add_medicine.html       # Add medicine form with client & server validation
│   ├── edit_medicine.html      # Update inventory record
│   ├── medicine_details.html   # Risk profile meter & "Why this score?" breakdown
│   ├── priority_queue.html     # FEFO Smart Priority Queue ranking table
│   ├── expiry_alerts.html      # Categorized time-horizon alert tabs
│   ├── reports.html            # Printable loss prevention report & financial risk summary
│   └── includes/
│       └── alert_table.html    # Reusable Jinja alert table snippet
│
└── static/
    ├── css/
    │   └── style.css           # Custom healthcare UI styling & badge themes
    └── js/
        └── dashboard.js        # Interactive Chart.js setup & sidebar handler
```

---

## ⚡ Quick Start & Running Instructions

### Prerequisites
- Python 3.8+ installed on your system.

### Steps to Run:
1. **Open your terminal / command prompt** and navigate to the project directory:
   ```bash
   cd medicine-expiry-risk-system
   ```

2. **Install required dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the Flask Server**:
   ```bash
   python app.py
   ```

4. **Access the application in your web browser**:
   Open `http://127.0.0.1:5000`

*Note: The SQLite database and realistic sample data will automatically initialize on the first launch.*

---

## 🎓 How to Explain This Project to a Teacher / Evaluator

When presenting this project in a college viva or mini-project demonstration, highlight the following core points:

1. **Not Just a CRUD App**: Emphasize that this is a **Priority-Based Decision Support System (DSS)**, not just a basic database CRUD application.
2. **Multi-Factor Intelligence vs. Simple Sorting**:
   - *Traditional system*: "Sort by Expiry Date ASC" -> misses high-quantity or high-value items that are about to expire.
   - *Our system*: Evaluates **Expiry Proximity + Quantity Exposure + Financial Capital + Sales Velocity**.
3. **FEFO Integration**: Explain how the **Smart Priority Queue** enforces FEFO (First-Expiry, First-Out) dispensing to prevent medicine spoilage before it happens.
4. **Transparent Risk Audit**: Show the **Medicine Details** page to demonstrate that the AI/algorithm is completely explainable ("White-Box"), showing exact percentage weights and bullet points for teacher evaluation.

---

## 🚀 Future Enhancements
- Integration with barcode/QR code scanners for quick batch entry.
- Automated email/SMS alert dispatch to pharmacy managers for Critical items.
- Multi-branch stock transfer request workflow.
