import os
import sys

# Add parent directory to sys.path so app can be imported
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from app import app, ensure_db

# Initialize database tables and folders on serverless cold starts
ensure_db()
